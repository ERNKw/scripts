INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
	('watering_can', 'Watering Can', 500, 0, 1),
	('fertilizer', 'fertilizer', 500, 0, 1),
	('advanced_fertilizer', 'Advanced Fertilizer', 500, 0, 1),
	('liquid_fertilizer', 'Liquid Fertilizer', 200, 0, 1),
	('weed_lemonhaze_seed', 'Weed Lemonhaze Seed', 20, 0, 1),
	('weed_lemonhaze', 'Weed Lemonhaze', 20, 0, 1),
	('coca_seed', 'Coca Seed', 20, 0, 1),
	('coca', 'Coca', 20, 0, 1),
	('paper', 'Paper', 20, 0, 1),
	('nitrous', 'nitrous', 20, 0, 1),
	('cocaine', 'cocaine', 20, 0, 1),
	('joint', 'joint', 20, 0, 1),
	('weed_processing_table', 'weed_processing_table', 1000, 0, 1),
	('cocaine_processing_table', 'cocaine_processing_table', 1000, 0, 1)
;