Config = {
    {
        startPos = vec3(750.788391, 1226.388672, 362.829773),
        startLookAt = vec3(426.633881, 92.647377, 275.875397),
        endPos = vec3(720.180664, 1151.766235, 348.350891),
        endLookAt = vec3(426.633881, 92.647377, 275.875397),
        duration = 10000,
        text = "Welcome to Los Santos !",
        time = { h = 22, m = 0 }
    },
    {
        startPos = vec3(-549.201904, -302.656128, 59.658916),
        startLookAt = vec3(-556.870544, -224.754593, 57.415646),
        endPos = vec3(-440.492035, -255.587021, 56.175003),
        endLookAt = vec3(-520.850098, -207.685928, 57.415646),
        duration = 10000,
        text = "The city is full of life !",
        time = { h = 12, m = 0 }
    }
}